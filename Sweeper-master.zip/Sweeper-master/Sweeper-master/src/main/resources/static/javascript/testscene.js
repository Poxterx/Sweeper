class TestScene extends Phaser.Scene {
    /**
     * Escena para probar la clase UsersList
     */
    constructor() {
        super({ key: "TestScene" });
        //this.us = new UsersList(this);
    }
    update() {
        this.us.update();
    }
}
//# sourceMappingURL=testscene.js.map